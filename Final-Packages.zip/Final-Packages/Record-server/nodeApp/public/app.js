document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("record-form");
    const fullNameInput = document.getElementById("full-name");
    const recordsContainer = document.getElementById("records-container");
    const postRecordsButton = document.getElementById("post-records");

    // Fetch records from the server
    async function loadRecords() {
        try {
            const response = await fetch('/api/records');
            const records = await response.json();
            recordsContainer.innerHTML = ''; // Clear existing records

            records.forEach(record => {
                const recordElement = createRecordElement(record);
                recordsContainer.appendChild(recordElement);
            });
        } catch (error) {
            console.error("Error loading records:", error);
        }
    }

    // Create a record element
    function createRecordElement(record) {
        const recordDiv = document.createElement("div");
        recordDiv.className = "record";
        recordDiv.dataset.id = record.id;

        const span = document.createElement("span");
        span.textContent = record.name;

        const deleteButton = document.createElement("button");
        deleteButton.textContent = "Remove";
        deleteButton.style.height = "36px";
        deleteButton.addEventListener("click", async () => {
            try {
                const response = await fetch(`/api/records/${record.id}`, { method: 'DELETE' });
                if (response.ok) {
                    recordDiv.remove();
                } else {
                    console.error("Error deleting record:", response.statusText);
                }
            } catch (error) {
                console.error("Error deleting record:", error);
            }
        });

        recordDiv.appendChild(span);
        recordDiv.appendChild(deleteButton);

        return recordDiv;
    }

    // Event listener for form submission
    form.addEventListener("submit", async (e) => {
        e.preventDefault();

        const fullName = fullNameInput.value.trim();
        if (fullName) {
            try {
                const response = await fetch('/api/records', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ name: fullName })
                });

                if (response.ok) {
                    const newRecord = await response.json();
                    const recordElement = createRecordElement(newRecord);
                    recordsContainer.appendChild(recordElement);
                    fullNameInput.value = "";
                } else {
                    console.error("Error adding record:", response.statusText);
                }
            } catch (error) {
                console.error("Error adding record:", error);
            }
        }
    });

    // Initial load
    loadRecords();
});